// отображение названия загружаемого изображения
$('.file input').change(function() {
    var val = $(this).val().split('\\').pop();
    $(this).parent().find('.file__value').text(val);
});