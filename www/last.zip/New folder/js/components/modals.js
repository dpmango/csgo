$('#levelModal .modal__close').click(function() {
    $('.level-modal__num-new').removeClass('level-modal__num-new');
});